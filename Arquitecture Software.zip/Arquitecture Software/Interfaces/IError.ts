export interface IError{
    NOTFOUND(error: string): void;
    VALIDATIONERROR(error: string): void;
}