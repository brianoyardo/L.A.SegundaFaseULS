import { Libro } from "../Entities/Libro";
import { LibroRepository } from "../Repositories/LibroRepository";
import { ErrorLogger } from "../utils/Error";
import { AutorService } from "./AutorService";


export class LibroService {
    constructor(private libroRepository: LibroRepository, private autorService: AutorService, private ErrorLogger: ErrorLogger) {}

    agregarLibro(titulo: string, autorId: number): Libro {
        const autor = this.autorService.obtenerAutor(autorId);
        if (!autor) throw this.ErrorLogger.VALIDATIONERROR;

        const libro = new Libro(Date.now(), titulo, autor);
        this.libroRepository.agregar(libro);
        return libro;
    }

    obtenerLibro(id: number): Libro | undefined {
        if(!id){
            return this.libroRepository.obtenerPorId(id);
        }
        else{
            this.ErrorLogger.NOTFOUND;
        }
    }
}
