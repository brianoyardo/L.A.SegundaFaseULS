import { IError } from "../Interfaces/IError";

export class ErrorLogger implements IError {
    NOTFOUND(error: string): void {
        throw new Error("Not Found.");
    }
    VALIDATIONERROR(error: string): void {
        throw new Error("Validation Error.");
    }
}