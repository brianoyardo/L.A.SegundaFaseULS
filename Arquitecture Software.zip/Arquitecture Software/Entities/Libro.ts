import { Autor } from "./Autor";

export class Libro {
    constructor(public id: number, public titulo: string, public autor: Autor) {}
}
