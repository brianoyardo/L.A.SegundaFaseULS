export class Autor {
    constructor(public id: number, public nombre: string, public fechaNacimiento: Date) {}
}
