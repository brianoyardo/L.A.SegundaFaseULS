export interface AutorDTO {
    id: number;
    nombre: string;
    fechaNacimiento: string;
    edad: number;
}
