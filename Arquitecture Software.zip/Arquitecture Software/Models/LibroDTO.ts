export interface LibroDTO {
    id: number;
    titulo: string;
    autorId: number;
}
